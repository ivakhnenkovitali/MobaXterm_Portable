XERXES

XerXes - Most powerful dos tool bY mR.Thg

COMPILE

gcc -o xerxes xerxes.c

LINUX/UNIX/MAC

./xerxes IP PORT

BE ANONYMOUS
USE PROXY VPN OPENVPN TOR PROXYCHAINS

https://en.wikipedia.org/wiki/The_Jester_%28hacktivist%29

https://twitter.com/th3j35t3r

http://jesterscourt.cc/

XERXES
